Ambermoon Advanced English 1.03 by Pyrdacor (01-02-2023)
========================================================

Ambermoon Advanced is an extension of Ambermoon.

It adds content like new places, quests, monsters, NPCs and items.
Moreover it changes a few aspects of the game to balance it, add a
bit more challenge or make some aspects or characters more valuable.

Version 1.0X is the first official release and contains the first
two episodes "Mysteries of the sea" and "Elemental creatures".
The state of bugfixes is mostly based on original version 1.17 english.


Questions, bug reports or suggestions?

Email: trobt@web.de
Twitter: @Pyrdacor2
Github: https://github.com/Pyrdacor


You want to support this and other projects?

Patreon: https://www.patreon.com/Pyrdacor
Github Sponsor: https://github.com/sponsors/Pyrdacor
Donate: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=76DV5MK5GNEMS