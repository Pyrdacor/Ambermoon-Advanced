Ambermoon Advanced German 1.33 by Pyrdacor (22-08-2025)
=======================================================

Ambermoon Advanced is an extension of Ambermoon.

It adds content like new places, quests, monsters, NPCs and items.
Moreover it changes a few aspects of the game to balance it, add a
bit more challenge or make some aspects or characters more valuable.

Version 1.3x contains the first 3 episodes:

- Mysteries of the see
- Elemental creatures
- The green jewel

The state of bugfixes is mostly based on original version 1.18 german.

========================================================
1.33 Changes
========================================================

- Adds a hint for the light riddle in Antique Area 3
- Fixes APR calculation to use 1 + Level / APRLevelValue

========================================================
1.32 Changes
========================================================

- Fixed crash when entering air ship on forest moon

========================================================
1.31 Changes
========================================================

- Removed Gizzek encounters in Dor Kiredon
- Egil's max attacks per round increased to 8 from 5 (only new savegames)
- Fixed a bug where Aman didn't give you a quest when defeating the bandits before
- APR increases through quests did not last after level up (fixed now)
- Looking at Gryban no longer crashes the game
- Weakened the Gizzek Queen a bit

========================================================


Questions, bug reports or suggestions?

Email: trobt@web.de
Twitter/X: @Pyrdacor
Github: https://github.com/Pyrdacor


You want to support this and other projects?

Patreon: https://www.patreon.com/Pyrdacor
Github Sponsor: https://github.com/sponsors/Pyrdacor
Donate: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=76DV5MK5GNEMS